using System;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {
        private TextBox display;
        private Button[] numberButtons;
        private Button addButton, subtractButton, multiplyButton, divideButton, equalsButton, clearButton;
        private string input = string.Empty;
        private string operand1 = string.Empty;
        private string operand2 = string.Empty;
        private char operation;
        private double result = 0.0;

        public Form1()
        {
            InitializeComponent();
            InitializeCalculator();
        }

        private void InitializeCalculator()
        {
            // Configuração da janela principal
            this.Text = "Calculadora";
            this.Width = 300;
            this.Height = 400;

            // Configuração do display
            display = new TextBox();
            display.Width = 260;
            display.Height = 30;
            display.Top = 20;
            display.Left = 10;
            display.TextAlign = HorizontalAlignment.Right;
            this.Controls.Add(display);

            // Configuração dos botões numéricos
            numberButtons = new Button[10];
            for (int i = 0; i < 10; i++)
            {
                numberButtons[i] = new Button();
                numberButtons[i].Text = i.ToString();
                numberButtons[i].Width = 60;
                numberButtons[i].Height = 40;
                numberButtons[i].Left = (i % 3) * 70 + 10;
                numberButtons[i].Top = ((i - 1) / 3) * 50 + 70;
                if (i == 0)
                {
                    numberButtons[i].Top = 220;
                    numberButtons[i].Left = 80;
                }
                numberButtons[i].Click += new EventHandler(NumberButton_Click);
                this.Controls.Add(numberButtons[i]);
            }

            // Configuração dos botões de operações
            addButton = new Button();
            addButton.Text = "+";
            addButton.Width = 60;
            addButton.Height = 40;
            addButton.Left = 220;
            addButton.Top = 70;
            addButton.Click += new EventHandler(OperationButton_Click);
            this.Controls.Add(addButton);

            subtractButton = new Button();
            subtractButton.Text = "-";
            subtractButton.Width = 60;
            subtractButton.Height = 40;
            subtractButton.Left = 220;
            subtractButton.Top = 120;
            subtractButton.Click += new EventHandler(OperationButton_Click);
            this.Controls.Add(subtractButton);

            multiplyButton = new Button();
            multiplyButton.Text = "*";
            multiplyButton.Width = 60;
            multiplyButton.Height = 40;
            multiplyButton.Left = 220;
            multiplyButton.Top = 170;
            multiplyButton.Click += new EventHandler(OperationButton_Click);
            this.Controls.Add(multiplyButton);

            divideButton = new Button();
            divideButton.Text = "/";
            divideButton.Width = 60;
            divideButton.Height = 40;
            divideButton.Left = 220;
            divideButton.Top = 220;
            divideButton.Click += new EventHandler(OperationButton_Click);
            this.Controls.Add(divideButton);

            equalsButton = new Button();
            equalsButton.Text = "=";
            equalsButton.Width = 60;
            equalsButton.Height = 40;
            equalsButton.Left = 150;
            equalsButton.Top = 220;
            equalsButton.Click += new EventHandler(EqualsButton_Click);
            this.Controls.Add(equalsButton);

            clearButton = new Button();
            clearButton.Text = "C";
            clearButton.Width = 60;
            clearButton.Height = 40;
            clearButton.Left = 10;
            clearButton.Top = 220;
            clearButton.Click += new EventHandler(ClearButton_Click);
            this.Controls.Add(clearButton);
        }

        private void NumberButton_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            input += button.Text;
            display.Text = input;
        }

        private void OperationButton_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            operand1 = input;
            operation = Convert.ToChar(button.Text);
            input = string.Empty;
        }

        private void EqualsButton_Click(object sender, EventArgs e)
        {
            operand2 = input;
            double num1, num2;
            double.TryParse(operand1, out num1);
            double.TryParse(operand2, out num2);

            switch (operation)
            {
                case '+':
                    result = num1 + num2;
                    break;
                case '-':
                    result = num1 - num2;
                    break;
                case '*':
                    result = num1 * num2;
                    break;
                case '/':
                    if (num2 != 0)
                    {
                        result = num1 / num2;
                    }
                    else
                    {
                        MessageBox.Show("Divisão por zero não é permitida.");
                    }
                    break;
            }
            display.Text = result.ToString();
            input = string.Empty;
            operand1 = string.Empty;
            operand2 = string.Empty;
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            input = string.Empty;
            operand1 = string.Empty;
            operand2 = string.Empty;
            display.Text = string.Empty;
        }
    }
}

